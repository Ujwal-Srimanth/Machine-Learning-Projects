import streamlit as st
import re
import pandas as pd
import helper
import collections
import matplotlib.pyplot as plt


def preprocess(data):
    pattern = '\d{1,2}/\d{1,2}/\d{2,4},\s\d{1,2}:\d{2}\s-\s'
    messages = re.split(pattern,data)[1:]
    dates = re.findall(pattern,data)
    df = pd.DataFrame({'user_message':messages,'message_date':dates})
    df['message_date'] = pd.to_datetime(df['message_date'], format='%d/%m/%y, %H:%M - ')
    df.rename(columns={'message_date':'date'},inplace=True)
    users=[]
    messages=[]
    for message in df['user_message']:
        entry = re.split('([\w\W]+?):\s',message)
        if entry[1:]:
            users.append(entry[1])
            messages.append(entry[2])
        else:
            users.append('group_notification')
            messages.append(entry[0])
    df['user']=users
    df['messages']=messages
    df.drop(columns='user_message',inplace=True)
    df['year']=df['date'].dt.year
    df['month']=df['date'].dt.month_name()
    df['day']=df['date'].dt.day
    df['hour']=df['date'].dt.hour
    df['minute']=df['date'].dt.minute
    return df
st.sidebar.title('Whatsapp Chat Analyzer')
uploaded_file = st.file_uploader("Choose a file")
if uploaded_file is not None:
    bytes_data = uploaded_file.getvalue()
    data = bytes_data.decode('utf-8')
    df = preprocess(data)
    st.dataframe(df)
    user_list = df['user'].unique().tolist()
    user_list.remove('group_notification')
    user_list.sort()
    user_list.insert(0,"Overall")
    selected_user = st.sidebar.selectbox("Show analysis wrt",user_list)
    if st.sidebar.button("Show analysis"):
        col1,col2,col3,col4 = st.columns(4)
        no_messages,no_words,no_media,no_links = helper.fetch_stats(selected_user,df)
        with col1:
            st.header("Total Meaages")
            st.title(no_messages)
        with col2:
            st.header('Total Words')
            st.title(no_words)
        with col3:
            st.header('Media Messages')
            st.title(no_media)
        with col4:
            st.header('Links Shared')
            st.title(no_links)
        #finding the busiest user
        
        
        if selected_user == 'Overall':
            
            x = df['user'].value_counts().head()
            col1,col2 = st.columns(2)
            import matplotlib.pyplot as plt
            fig,ax = plt.subplots()
            with col1:
                st.title("Top 5 Active Users")
                ax.bar(x.index, x.values)
                plt.xticks(rotation='vertical')
                st.pyplot(fig)
            with col2:
                st.title("Percentage of users")
                new_df = round((df['user'].value_counts()/df.shape[0])*100,2).reset_index().rename(columns={'user':'name','count':'%'})
                st.dataframe(new_df,width=400,height=340)
    #word cloud
    st.title('Word Cloud')
    ss = df[df['messages']!='group_notification']
    ss = ss[ss['messages']!='<Media omitted>\n']
    wc = helper.create_word_cloud(selected_user,ss)
    import matplotlib.pyplot as plt
    fig,ax = plt.subplots()
    ax.imshow(wc)
    st.pyplot(fig)

    def remove_special_characters(text):
    # Define the pattern to match special characters
        pattern = r'[^a-zA-Z0-9\s]'  # Keep only alphanumeric characters and whitespace

        # Replace special characters with an empty string
        cleaned_text = re.sub(pattern, '', text)
        
        return cleaned_text


    st.title('Top 20 used Words')
    if selected_user!='Overall':
        df = df[df['user']==selected_user]
    ss = df[df['messages']!='group_notification']
    ss = ss[ss['messages']!='<Media omitted>\n']
    words =[]
    for i in ss['messages']:
        mp = remove_special_characters(i)
        words.extend(mp.split())
    from collections import Counter
    m = pd.DataFrame(Counter(words).most_common(20))
    col1,col2 = st.columns(2)
    with col1:
        st.dataframe(m,width=300)
    with col2:     
        fig,ax = plt.subplots(figsize=(10, 11))
        ax.bar(m[0],m[1])
        plt.xticks(rotation='vertical')
        plt.figure(figsize=(30,30))
        st.pyplot(fig)

        

    st.title('Emojis')    
    col3,col4 = st.columns(2)
    if selected_user == 'Overall':
        import emoji
        emojis = []
        for message in df['messages']:
            emojis.extend([c for c in message if c in emoji.EMOJI_DATA])
        emoji_df=pd.DataFrame(Counter(emojis).most_common(len(Counter(emojis))))
        
    else:
        import emoji
        emojis = []
        for message in df[df['user']==selected_user]['messages']:
            emojis.extend([c for c in message if c in emoji.EMOJI_DATA])
        emoji_df=pd.DataFrame(Counter(emojis).most_common(len(Counter(emojis))))
    with col3:
        st.dataframe(emoji_df,width=200,height=340)
    with col4:
        fig,ax = plt.subplots()
        ax.pie(emoji_df[1],labels=emoji_df[0])
        st.pyplot(fig)


    st.title('Timeline')
    if selected_user != 'Overall':
        df = df[df['user']==selected_user]
    month_name_to_num = {
    'January': 1, 'February': 2, 'March': 3, 'April': 4, 'May': 5, 'June': 6,
    'July': 7, 'August': 8, 'September': 9, 'October': 10, 'November': 11, 'December': 12
    }
    df['month_num'] = df['month'].map(month_name_to_num)
    timeline = df.groupby(['year','month_num','month']).count()['messages'].reset_index()
    time = []
    for i in range(timeline.shape[0]):
        time.append(timeline['month'][i] +" - "+str(timeline['year'][i]))
    timeline['time'] = time
    fig,ax = plt.subplots()
    ax.plot(timeline['time'],timeline['messages'])
    plt.xticks(rotation='vertical')
    st.pyplot(fig)


    st.title('Daily Timeline')
    if selected_user != 'Overall':
        df = df[df['user']==selected_user]
    df['only_date']=df['date'].dt.date
    daily_timeline = df.groupby('only_date').count()['messages'].reset_index()
    fig,ax = plt.subplots()
    ax.plot(daily_timeline['only_date'],daily_timeline['messages'])
    plt.xticks(rotation='vertical')
    st.pyplot(fig)


    if selected_user != 'Overall':
        df = df[df['user']==selected_user]
    df['day_name']=df['date'].dt.day_name()
    bu = df['day_name'].value_counts()
    fu = df['month'].value_counts()
    st.title("Activity Map")
    col1,col2 = st.columns(2)
    with col1:
        st.header("Most Busy Day")
        fig,ax = plt.subplots()
        ax.bar(bu.index,bu.values)
        plt.xticks(rotation='vertical')
        st.pyplot(fig)
    with col2:
        st.header("Most Busy Month")
        fig,ax = plt.subplots()
        ax.bar(fu.index,fu.values)
        plt.xticks(rotation='vertical')
        st.pyplot(fig)



    




    


    
    

        

    


            








