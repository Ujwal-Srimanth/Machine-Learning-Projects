from urlextract import URLExtract
from wordcloud import WordCloud
import matplotlib.pyplot as plt
def fetch_stats(user_type,df):

    
    if user_type == 'Overall':
        num_messages = df.shape[0]

        words = []
        for messages in df['messages']:
            words.extend(messages.split())
        num_media = df[df['messages']=='<Media omitted>\n'].shape[0]

        links = []
        extractor = URLExtract()
        for message in df['messages']:
            links.extend(extractor.find_urls(message))
        
        return num_messages, len(words),num_media,len(links)

    else:
        num_messages =  df[df['user']==user_type].shape[0]
        words = []
        for messages in df[df['user']==user_type]['messages']:
            words.extend(messages.split())
        num_media = df[df['user']==user_type][df['messages']=='<Media omitted>\n'].shape[0]
        links = []
        extractor = URLExtract()
        for message in df[df['user']==user_type]['messages']:
            links.extend(extractor.find_urls(message))
        return num_messages, len(words),num_media,len(links)
def create_word_cloud(selected_user,df):
    if selected_user!='Overall':
        df = df[df['user']==selected_user]
    wc = WordCloud(width=500,height=500,min_font_size=10)
    df_wc = wc.generate(df['messages'].str.cat(sep = " "))
    return df_wc
    


